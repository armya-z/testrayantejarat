function Post() {
  return (
    <>
      <div className="post">
        <h1>Title of the post</h1>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Veniam
          obcaecati facere repellendus dignissimos, inventore incidunt quis
          velit dolorum explicabo, quisquam, ipsam autem modi similique
          voluptatem eaque iusto recusandae architecto. Aliquam, dignissimos!
          Quisquam, iure earum quod id eius tempora voluptatem ex voluptas
          illum, quam nobis aperiam atque animi iste aut ipsum deserunt dolores
          saepe architecto cumque in adipisci nihil? Obcaecati ipsam laborum ad
          consequatur maiores eum. Soluta suscipit exercitationem repellendus
          numquam beatae fuga dolorem dignissimos ab aliquam amet molestias
          voluptas minus dolores magnam repudiandae culpa, ratione rem
          laboriosam natus autem, eaque ipsam incidunt perspiciatis? Ullam
          minima, quae eaque necessitatibus maxime nostrum, sint, fugit rem
          assumenda corporis magnam deleniti ab deserunt sunt recusandae
          molestiae delectus nobis voluptatibus repellat libero perspiciatis
          dolor. Modi aperiam molestiae alias dignissimos aliquam porro omnis,
          reprehenderit sint quisquam cumque dicta tempore voluptates molestias
          numquam laboriosam facere non accusantium sequi. At illum iusto
          voluptas aliquid voluptates odit, explicabo veniam quas provident?
        </p>
      </div>
      <hr />
    </>
  );
}

export default Post;
